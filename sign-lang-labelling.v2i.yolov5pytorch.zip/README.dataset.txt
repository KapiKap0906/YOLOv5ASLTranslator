# sign-lang-labelling > 2025-04-17 7:11pm
https://universe.roboflow.com/kapstudying/sign-lang-labelling

Provided by a Roboflow user
License: CC BY 4.0

